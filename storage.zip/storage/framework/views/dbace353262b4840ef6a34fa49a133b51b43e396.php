<?php $__env->startSection('content'); ?>

    <?php if($innerBannerContent = $content->where('slug', 'coffeeInnerBanner')->first()): ?>
        <div class="innerBanner">
            <img src="<?php echo e(asset($innerBannerContent->content['img']['value'])); ?>" class="w-100" alt="">
            <div class="overlay">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <h2><?php echo e($innerBannerContent->content['h2']['value']); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Menu Sec Start -->
    <?php if($menuSecContent = $content->where('slug', 'coffeeMenuSec')->first()): ?>
        <section class="menuSec">
            <img src="<?php echo e(asset($menuSecContent->content['img'][0]['value'])); ?>" class="img-fluid img12" alt="">
            <img src="<?php echo e(asset($menuSecContent->content['img'][1]['value'])); ?>" class="img-fluid img13" alt="">
            <div class="container">
                <h2 class="secHeading text-center mb-5">
                    <?php echo $menuSecContent->content['coffeeMenuContainer']['secHeading']['value']; ?>

                </h2>
                <?php if(count($categories)): ?>
                    <div class="row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="cofeHeading">
                                    <h2><?php echo e($category->name); ?></h2>
                                </div>

                                <?php $__empty_1 = true; $__currentLoopData = app('Webkul\Product\Repositories\ProductRepository')->getAll($category->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFlat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="cofeList">
                                        <a href="<?php echo e(route('shop.home.show', $productFlat->url_key)); ?>" class="codeBox">
                                            <figure><img
                                                    src="<?php echo e(productimage()->getProductBaseImage($productFlat)['small_image_url']); ?>"
                                                    class="img-fluid"
                                                    alt="img"></figure>
                                            <div class="cofeContent">
                                                <ul>
                                                    <li>
                                                        <h2><?php echo e($productFlat->name); ?></h2>
                                                        <div class="dot"></div>
                                                        <span>
                                                        <?php if(isset($productFlat->special_price)): ?>
                                                                <del>$<?php echo e(round($productFlat->price)); ?></del>
                                                                <strong>$<?php echo e(round($productFlat->special_price)); ?></strong>
                                                            <?php else: ?>
                                                                <strong>$<?php echo e(round($productFlat->price)); ?></strong>
                                                            <?php endif; ?>
                                                    </span>
                                                    </li>
                                                </ul>
                                                <p><?php echo e($productFlat->description); ?></p>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="cofeList">
                                        <div class="codeBox">
                                            <p>No product found.</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
    <!-- Menu Sec End -->


    <!-- Delight Sec Start -->
    <?php if($coffeeInnerContent = $content->where('slug', 'coffeeInner')->first()): ?>
        <section class="aboutSec delightSec coffeInner">
            <div class="aboutTop">
                <img src="<?php echo e(asset($coffeeInnerContent->content['coffeeAboutTop']['img'][0]['value'])); ?>" class="img-fluid img8" alt="">
                <img src="<?php echo e(asset($coffeeInnerContent->content['coffeeAboutTop']['img'][1]['value'])); ?>" class="delgithRight" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-5">
                        <div class="abtOne">
                            <figure>
                                <img src="<?php echo e(asset($coffeeInnerContent->content['coffeeInnerContainer']['abtOne']['img']['value'])); ?>"
                                     class="img-fluid" alt="">
                            </figure>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="Line"></div>
                        <div class="aboutTwo">
                            <h3><?php echo $coffeeInnerContent->content['coffeeInnerContainer']['aboutTwo']['h3']['value']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <p><?php echo e($coffeeInnerContent->content['coffeeInnerContainer']['align-items-center']['col-md-4-1']['p']['value']); ?></p>
                        <figure class="delightLogo">
                            <img
                                src="<?php echo e(asset($coffeeInnerContent->content['coffeeInnerContainer']['align-items-center']['col-md-4-1']['img']['value'])); ?>"
                                class="img-fluid"
                                alt="">
                        </figure>
                    </div>
                    <div class="col-md-4">
                        <h4><?php echo e($coffeeInnerContent->content['coffeeInnerContainer']['align-items-center']['col-md-4-2']['h4']['value']); ?></h4>
                        <figure>
                            <img
                                src="<?php echo e(asset($coffeeInnerContent->content['coffeeInnerContainer']['align-items-center']['col-md-4-2']['img']['value'])); ?>"
                                class="img-fluid" alt="">
                        </figure>
                    </div>
                    <div class="col-md-4">
                        <div class="centerImg">
                            <figure>
                                <img
                                    src="<?php echo e(asset($coffeeInnerContent->content['coffeeInnerContainer']['align-items-center']['col-md-4-3']['img']['value'])); ?>"
                                    class="img-fluid img11"
                                    alt="">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <img src="<?php echo e(asset($coffeeInnerContent->content['coffeeInnerContainer']['container-end']['img'][0]['value'])); ?>"
                 class="img-fluid img6" alt="">
            <img src="<?php echo e(asset($coffeeInnerContent->content['coffeeInnerContainer']['container-end']['img'][1]['value'])); ?>"
                 class="img-fluid delgithLft" alt="">
        </section>
    <?php endif; ?>
    <!-- Delight Sec End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/coffee.blade.php ENDPATH**/ ?>