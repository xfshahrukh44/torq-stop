<?php $__env->startSection('content'); ?>

    <?php if($innerBannerContent = $content->where('slug', 'merchandiseInnerBanner')->first()): ?>
        <div class="innerBanner">
            <img src="<?php echo e(asset($innerBannerContent->content['img']['value'] )); ?>" class="w-100" alt="">
            <div class="overlay">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <h2><?php echo e($innerBannerContent->content['h2']['value']); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Product Sec Start -->
    <section class="productSec">
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <div class="productBox">
                            <figure>
                                <img
                                    src="<?php echo e(asset(productimage()->getProductBaseImage($newProduct)['large_image_url'])); ?>"
                                    class="img-fluid" alt="">
                            </figure>
                            <div class="productContent">
                                <h4>
                                    <?php echo e($newProduct->name); ?>

                                    <?php if(isset($newProduct->special_price)): ?>
                                        <span>$<?php echo e(round($newProduct->special_price)); ?></span>
                                    <?php else: ?>
                                        <span>$<?php echo e(round($newProduct->price)); ?></span>
                                    <?php endif; ?>
                                </h4>
                                <a href="<?php echo e(route('shop.home.show', $newProduct->url_key)); ?>" class="productBtn">ADD TO
                                    CART</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-4">
                        <div class="productBox">
                            <p>No product found.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Product Sec End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/merchandise.blade.php ENDPATH**/ ?>