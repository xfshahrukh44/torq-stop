<?php $__env->startSection('page_title'); ?>
    <?php echo e(__('shop::app.checkout.success.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <section class="ThankyouSec">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-7">
                        <div class="thankyouContent">
                            <div class="waviy ">
                                <span>T</span>
                                <span>H</span>
                                <span>A</span>
                                <span>N</span>
                                <span>K</span>
                                <span>Y</span>
                                <span>O</span>
                                <span>U</span>
                            </div>
                            <!-- <h5>Thank you  <span>for contacting us..</span></h5> -->
                            <p class="row col-12">
                                <?php echo e(__('shop::app.checkout.success.order-id-info', ['order_id' => $order->increment_id])); ?>

                            </p>

                            <p class="row col-12">
                                <?php echo e(__('shop::app.checkout.success.info')); ?>

                            </p>
                            <a href="<?php echo e(route('shop.home.index')); ?>">Return to Homepage</a>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="imageThanks">
                            <img src="<?php echo e(asset('themes/default/assets/images/thank.jpg')); ?>" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/velocity/views/checkout/success.blade.php ENDPATH**/ ?>