<!-- Begin: Footer -->
<footer>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="contactBox">
                    <a href="" class="contactInfo">
                        <img src="<?php echo e(asset('themes/default/assets/images/call.png')); ?>" class="img-fluid" alt="">
                        <div class="contactContent">
                            <h6>Openning Hours <span>11.30AM – 2.30PM</span></h6>
                        </div>
                    </a>
                    <a href="" class="contactInfo">
                        <img src="<?php echo e(asset('themes/default/assets/images/spin.png')); ?>" class="img-fluid" alt="">
                        <div class="contactContent">
                            <h6>Oklahoma City</h6>
                        </div>
                    </a>
                    <div class="icons">
                        <ul>
                            <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href=""><i class="fab fa-instagram"></i></a></li>
                            <li><a href=""><i class="fab fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footLine">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h6>Copyright © 2022 BRAND NEW DAY, All rights reserved.</h6>
                </div>
                <div class="col-md-6">
                    <ul>
                        <li><a href="<?php echo e(route('shop.terms')); ?>">Terms and Conditions</a></li>
                        <li><a href="<?php echo e(route('shop.privacy')); ?>">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- END: Footer --><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/layouts/footer/footer2.blade.php ENDPATH**/ ?>