<header>
    <div class="container">
        <nav class="navbar navbar-expand-lg p-0">
            <!--            <a class="navbar-brand" href="index.php">
                            <img src="images/logo.png" alt="logo">
                        </a>-->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="fa fa-bars"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(route('shop.home.index')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('shop.about')); ?>">About us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('shop.coffee')); ?>">Coffee</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('shop.merchandise')); ?>">Merchandise</a>
                    </li>
                </ul>
                <div class="headLogo">
                    <a class="navbar-brand" href="index.php">
                        <img src="<?php echo e(asset('themes/default/assets/images/logo.gif')); ?>" alt="logo">
                    </a>
                </div>
                <ul class="socialLinks m-auto">
                    <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href=""><i class="fab fa-instagram"></i></a></li>
                    <li><a href=""><i class="fab fa-twitter"></i></a></li>
                    <li><a href=""><i class="far fa-search"></i></a></li>
                </ul>
                <div class="form-inline">
                    <a href="<?php echo e(route('shop.contact')); ?>" class="themeBtn">CONTACT US</a>
                </div>
            </div>
        </nav>
    </div>
</header><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/layouts/header/index2.blade.php ENDPATH**/ ?>