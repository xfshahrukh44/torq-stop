<?php $__env->startSection('page_title'); ?>
    <?php echo e(__('admin::app.sales.orders.view-title', ['order_id' => $order->increment_id])); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-wrapper'); ?>

    <div class="content full-page">

        <div class="page-header">

            <div class="page-title">
                <h1>
                    <?php echo view_render_event('sales.order.title.before', ['order' => $order]); ?>


                    <i class="icon angle-left-icon back-link"
                       onclick="window.location = '<?php echo e(route('admin.sales.orders.index')); ?>'"></i>

                    <?php echo e(__('admin::app.sales.orders.view-title', ['order_id' => $order->increment_id])); ?>


                    <?php echo view_render_event('sales.order.title.after', ['order' => $order]); ?>

                </h1>
            </div>

            <div class="page-action">
                <?php echo view_render_event('sales.order.page_action.before', ['order' => $order]); ?>


                <?php if($order->canCancel() && bouncer()->hasPermission('sales.orders.cancel')): ?>
                    <a href="<?php echo e(route('admin.sales.orders.cancel', $order->id)); ?>" class="btn btn-lg btn-primary"
                       v-alert:message="'<?php echo e(__('admin::app.sales.orders.cancel-confirm-msg')); ?>'">
                        <?php echo e(__('admin::app.sales.orders.cancel-btn-title')); ?>

                    </a>
                <?php endif; ?>

                <?php if($order->canInvoice() && $order->payment->method !== 'paypal_standard'): ?>
                    <a href="<?php echo e(route('admin.sales.invoices.create', $order->id)); ?>" class="btn btn-lg btn-primary">
                        <?php echo e(__('admin::app.sales.orders.invoice-btn-title')); ?>

                    </a>
                <?php endif; ?>

                <?php if($order->canRefund()): ?>
                    <a href="<?php echo e(route('admin.sales.refunds.create', $order->id)); ?>" class="btn btn-lg btn-primary">
                        <?php echo e(__('admin::app.sales.orders.refund-btn-title')); ?>

                    </a>
                <?php endif; ?>

                <?php if($order->canShip()): ?>
                    <a href="<?php echo e(route('admin.sales.shipments.create', $order->id)); ?>" class="btn btn-lg btn-primary">
                        <?php echo e(__('admin::app.sales.orders.shipment-btn-title')); ?>

                    </a>
                <?php endif; ?>

                <?php echo view_render_event('sales.order.page_action.after', ['order' => $order]); ?>

            </div>
        </div>

        <div class="page-content">

            <tabs>
                <?php echo view_render_event('sales.order.tabs.before', ['order' => $order]); ?>


                <tab name="<?php echo e(__('admin::app.sales.orders.info')); ?>" :selected="true">
                    <div class="sale-container">

                        <accordian :title="'<?php echo e(__('admin::app.sales.orders.order-and-account')); ?>'" :active="true">
                            <div slot="body">

                                <div class="sale">
                                    <div class="sale-section">
                                        <div class="secton-title">
                                            <span><?php echo e(__('admin::app.sales.orders.order-info')); ?></span>
                                        </div>

                                        <div class="section-content">
                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.order-date')); ?>

                                                </span>

                                                <span class="value">
                                                    <?php echo e($order->created_at); ?>

                                                </span>
                                            </div>

                                            <?php echo view_render_event('sales.order.created_at.after', ['order' => $order]); ?>


                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.order-status')); ?>

                                                </span>

                                                <span class="value">
                                                <?php echo e(__('admin::app.notification.order-status-messages.'.strtolower($order->status_label))); ?>

                                                </span>
                                            </div>

                                            <?php echo view_render_event('sales.order.status_label.after', ['order' => $order]); ?>


                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.channel')); ?>

                                                </span>

                                                <span class="value">
                                                    <?php echo e($order->channel_name); ?>

                                                </span>
                                            </div>

                                            <?php echo view_render_event('sales.order.channel_name.after', ['order' => $order]); ?>

                                        </div>
                                    </div>

                                    <div class="sale-section">
                                        <div class="secton-title">
                                            <span><?php echo e(__('admin::app.sales.orders.account-info')); ?></span>
                                        </div>

                                        <div class="section-content">
                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.customer-name')); ?>

                                                </span>

                                                <span class="value">
                                                    <?php echo e($order->customer_full_name); ?>

                                                </span>
                                            </div>

                                            <?php echo view_render_event('sales.order.customer_full_name.after', ['order' => $order]); ?>


                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.email')); ?>

                                                </span>

                                                <span class="value">
                                                    <?php echo e($order->customer_email); ?>

                                                </span>
                                            </div>

                                            <?php echo view_render_event('sales.order.customer_email.after', ['order' => $order]); ?>


                                            <?php if(! is_null($order->customer) && ! is_null($order->customer->group)): ?>
                                                <div class="row">
                                                    <span class="title">
                                                        <?php echo e(__('admin::app.customers.customers.customer_group')); ?>

                                                    </span>

                                                    <span class="value">
                                                        <?php echo e($order->customer->group->name); ?>

                                                    </span>
                                                </div>
                                            <?php endif; ?>

                                            <?php echo view_render_event('sales.order.customer_group.after', ['order' => $order]); ?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </accordian>

                        <?php if($order->billing_address || $order->shipping_address): ?>
                            <accordian :title="'<?php echo e(__('admin::app.sales.orders.address')); ?>'" :active="true">
                                <div slot="body">
                                    <div class="sale">
                                        <?php if($order->billing_address): ?>
                                            <div class="sale-section">
                                                <div class="secton-title">
                                                    <span><?php echo e(__('admin::app.sales.orders.billing-address')); ?></span>
                                                </div>

                                                <div class="section-content">
                                                    <?php echo $__env->make('admin::sales.address', ['address' => $order->billing_address], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                    <?php echo view_render_event('sales.order.billing_address.after', ['order' => $order]); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($order->shipping_address): ?>
                                            <div class="sale-section">
                                                <div class="secton-title">
                                                    <span><?php echo e(__('admin::app.sales.orders.shipping-address')); ?></span>
                                                </div>

                                                <div class="section-content">
                                                    <?php echo $__env->make('admin::sales.address', ['address' => $order->shipping_address], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                    <?php echo view_render_event('sales.order.shipping_address.after', ['order' => $order]); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </accordian>
                        <?php endif; ?>

                        <accordian :title="'<?php echo e(__('admin::app.sales.orders.payment-and-shipping')); ?>'" :active="true">
                            <div slot="body">

                                <div class="sale">
                                    <div class="sale-section">
                                        <div class="secton-title">
                                            <span><?php echo e(__('admin::app.sales.orders.payment-info')); ?></span>
                                        </div>

                                        <div class="section-content">
                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.payment-method')); ?>

                                                </span>

                                                <span class="value">
                                                    <?php echo e(core()->getConfigData('sales.paymentmethods.' . $order->payment->method . '.title')); ?>

                                                </span>
                                            </div>

                                            <div class="row">
                                                <span class="title">
                                                    <?php echo e(__('admin::app.sales.orders.currency')); ?>

                                                </span>

                                                <span class="value">
                                                    <?php echo e($order->order_currency_code); ?>

                                                </span>
                                            </div>















                                            <?php echo view_render_event('sales.order.payment-method.after', ['order' => $order]); ?>

                                        </div>
                                    </div>

                                    <?php if($order->shipping_address): ?>
                                        <div class="sale-section">
                                            <div class="secton-title">
                                                <span><?php echo e(__('admin::app.sales.orders.shipping-info')); ?></span>
                                            </div>

                                            <div class="section-content">
                                                <div class="row">
                                                    <span class="title">
                                                        <?php echo e(__('admin::app.sales.orders.shipping-method')); ?>

                                                    </span>

                                                    <span class="value">
                                                        <?php echo e($order->shipping_title); ?>

                                                    </span>
                                                </div>

                                                <div class="row">
                                                    <span class="title">
                                                        <?php echo e(__('admin::app.sales.orders.shipping-price')); ?>

                                                    </span>

                                                    <span class="value">
                                                        <?php echo e(core()->formatBasePrice($order->base_shipping_amount)); ?>

                                                    </span>
                                                </div>

                                                <?php echo view_render_event('sales.order.shipping-method.after', ['order' => $order]); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </accordian>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        

                        

                        
                        
                        
                        

                        
                        

                        
                        

                        
                        
                        

                        
                        
                        

                        

                        
                        
                        
                        

                        
                        
                        

                        
                        
                        

                        
                        
                        

                        
                        
                        
                        

                        

                        

                        

                        
                        
                        

                        
                        
                        
                        
                        
                        


                        
                        
                        
                        

                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        

                        
                        
                        
                        
                        

                        
                        
                        
                        
                        

                        
                        
                        
                        
                        

                        
                        

                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                    </div>
                </tab>

                

                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                

                

                
                
                
                
                
                
                
                
                
                
                
                

                

                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                

                

                
                
                
                
                
                
                
                
                
                
                
                
                

                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                

                

                
                
                
                
                
                
                
                
                
                

                

                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                

                
                
                

                

                <?php echo view_render_event('sales.order.tabs.after', ['order' => $order]); ?>

            </tabs>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/packages/Webkul/Admin/src/Providers/../Resources/views/sales/orders/view.blade.php ENDPATH**/ ?>