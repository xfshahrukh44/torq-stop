<?php $__env->startSection('content'); ?>

    <?php if($innerBannerContent = $content->where('slug', 'privacyInnerBanner')->first()): ?>
        <div class="innerBanner">
            <img src="<?php echo e(asset($innerBannerContent->content['img']['value'] )); ?>" class="w-100" alt="">
            <div class="overlay">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <h2><?php echo e($innerBannerContent->content['h2']['value']); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Terms Sec Start -->
    <?php if($termContent = $content->where('slug', 'privacyTerms')->first()): ?>
        <section class="terms">
            <div class="container">
                <?php echo $termContent->content['container']['value']; ?>

            </div>
        </section>
    <?php endif; ?>
    <!-- Terms Sec End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/privacy.blade.php ENDPATH**/ ?>