<?php $__env->startSection('content'); ?>
    <?php if($innerBannerContent = $content->where('slug', 'aboutUsInnerBanner')->first()): ?>
        <div class="innerBanner">
            <img src="<?php echo e(asset($innerBannerContent->content['img']['value'])); ?>" class="w-100" alt="">
            <div class="overlay">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <h2><?php echo e($innerBannerContent->content['h2']['value']); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>


    <!-- About Sec Start -->
    <?php if($innerAboutContent = $content->where('slug', 'inner-about')->first()): ?>
        <section class="aboutSec inner-about">
            <div class="aboutTop">
                <img src="<?php echo e(asset($innerAboutContent->content['aboutTop']['img'][0]['value'])); ?>" class="img-fluid img5" alt="">
                <img src="<?php echo e(asset($innerAboutContent->content['aboutTop']['img'][1]['value'])); ?>" class="img-fluid img6" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-between">
                    <div class="offset-md-1 col-md-4">
                        <div class="abtOne">
                            <figure>
                                <img src="<?php echo e(asset($innerAboutContent->content['abtOne']['img']['value'])); ?>" class="img-fluid" alt="">
                            </figure>
                            <h2><?php echo e($innerAboutContent->content['abtOne']['h2']['value']); ?></h2>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="Line"></div>
                        <div class="aboutTwo">
                            <h3><?php echo $innerAboutContent->content['aboutTwo']['h3']['value']; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <p><?php echo e($innerAboutContent->content['col-md-6']['p1']['value']); ?></p>
                        <p><?php echo e($innerAboutContent->content['col-md-6']['p2']['value']); ?></p>
                        <h5><?php echo e($innerAboutContent->content['col-md-6']['h5']['value']); ?></h5>
                        <p><?php echo e($innerAboutContent->content['col-md-6']['p3']['value']); ?></p>
                        <p><?php echo e($innerAboutContent->content['col-md-6']['p4']['value']); ?></p>
                    </div>
                    <div class="col-md-6">
                        <div class="aboutThree">
                            <figure>
                                <img src="<?php echo e(asset($innerAboutContent->content['aboutThree']['img']['value'])); ?>" class="img-fluid" alt="">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <img src="<?php echo e(asset($innerAboutContent->content['section-end']['img'][0]['value'])); ?>" class="img-fluid img7" alt="">
            <img src="<?php echo e(asset($innerAboutContent->content['section-end']['img'][1]['value'])); ?>" class="img-fluid img8" alt="">
        </section>
    <?php endif; ?>
    <!-- About Sec End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/about.blade.php ENDPATH**/ ?>