<?php $__env->startSection('page_title'); ?>
    <?php echo e(__('admin::app.cms.pages.edit-section')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h1>
                    <i class="icon angle-left-icon back-link"
                       onclick="window.location = '<?php echo e(route('admin.cms.index')); ?>'"></i>
                    Edit Section
                </h1>
            </div>
        </div>

        <div class="page-content">
            <div class="form-container">
                <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(route('admin.cms.updateSection', $key)); ?>"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <accordian title="<?php echo e(ucwords($key)); ?> Section" :active="false">
                            <div slot="body">
                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value['type'] === 'text'): ?>
                                        <?php $name = ''; ?>
                                        <?php $__currentLoopData = explode('>', $value['heading']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $name .= '['.trim($hValue).']'; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="control-group">
                                            <label for="page_title"
                                                   class="required"><?php echo e(ucwords($value['heading'])); ?></label>
                                            <input type="hidden" name="section<?php echo e($name.'[type]'); ?>" value="text">
                                            <input type="text" class="control"
                                                   name="section<?php echo e($name.'[value]'); ?>" required
                                                   value="<?php echo e($value['value']); ?>">
                                        </div>
                                    <?php endif; ?>
                                    <?php if($value['type'] === 'image'): ?>
                                        <?php $name = ''; ?>
                                        <?php $__currentLoopData = explode('>', $value['heading']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $name .= '['.trim($hValue).']'; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="control-group">
                                            <label class="required"><?php echo e(ucwords($value['heading'])); ?></label>
                                            <span
                                                class="control-info mt-10"><?php echo e(__('admin::app.settings.sliders.image-size')); ?></span>
                                            <input type="hidden" name="section<?php echo e($name.'[type]'); ?>" value="image">
                                            <image-wrapper button-label="<?php echo e(ucwords($value['heading'])); ?>"
                                                           input-name="section<?php echo e($name.'[value]'); ?>"
                                                           :multiple="false"
                                                           :images='"<?php echo e(asset($value['value'])); ?>"'></image-wrapper>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($value['type'] === 'html'): ?>
                                        <?php $name = ''; ?>
                                        <?php $__currentLoopData = explode('>', $value['heading']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $name .= '['.trim($hValue).']'; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="control-group">
                                            <label for="page_title"
                                                   class="required"><?php echo e(ucwords($value['heading'])); ?></label>
                                            <input type="hidden" name="section<?php echo e($name.'[type]'); ?>" value="html">
                                            <textarea type="text" class="control" name="section<?php echo e($name.'[value]'); ?>"
                                                      required><?php echo e($value['value']); ?></textarea>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="submit" class="btn btn-lg btn-primary">Update Section</button>
                            </div>
                        </accordian>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                

                
                
                
                
                

                
                
                
                
                

                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                

                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                

                
                
                
                
                

                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('admin::layouts.tinymce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function () {
            tinyMCEHelper.initTinyMCE({
                selector: 'textarea',
                height: 200,
                width: "100%",
                plugins: 'image imagetools media wordcount save fullscreen code table lists link hr',
                toolbar1: 'formatselect | bold italic strikethrough forecolor backcolor alignleft aligncenter alignright alignjustify | link hr |numlist bullist outdent indent  | removeformat | code | table',
                image_advtab: true,
                valid_elements: '*[*]',
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin::layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/packages/Webkul/Admin/src/Providers/../Resources/views/cms/edit-section.blade.php ENDPATH**/ ?>