<?php $__env->startSection('page_title'); ?>
    <?php echo e(__('shop::app.checkout.cart.title')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="innerBanner">
        <img src="<?php echo e(asset('themes\default\assets\images\innerBan.jpg')); ?>" class="w-100" alt="">
        <div class="overlay">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <h2>CONFIRM PURCHASE
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Begin: Step 2 -->
    <div class="checkOutStyle">
        <div class="container-md">
            <?php if(!is_null($cart) && $cart->items->count() > 0): ?>
                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $baseImage = productimage()->getProductBaseImage($item)['small_image_url'] ?>
                    <div class="row cartItemCard">
                        <div class="col-sm-2">
                            <img src="<?php echo e($baseImage); ?>" alt="">
                        </div>
                        <div class="col-md-5 col-sm-4">
                            <h4><?php echo e($item->name); ?></h4>
                        </div>
                        <div class="col-sm-2">
                            <strong class="price">$<?php echo e($item->price); ?></strong>
                        </div>
                        <div class="col-md-2 col-sm-3">
                            <div class="proCounter">
                                <span class="minus action-btn <?php echo e($item->quantity > 1 ? 'rmvQty' : null); ?>" data-id="<?php echo e($item->id); ?>"
                                      data-qty="<?php echo e($item->quantity); ?>">-</span>
                                <input type="text" value="<?php echo e($item->quantity); ?>"/>
                                <span class="plus addQty action-btn" data-id="<?php echo e($item->product_id); ?>"
                                      data-qty="<?php echo e($item->quantity); ?>">+</span>
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <a href="<?php echo e(route('shop.checkout.cart.remove', $item->id)); ?>" class="delete action-btn"
                               onclick="removeLink('<?php echo e(__('shop::app.checkout.cart.cart-remove-action')); ?>')">
                                <i class="far fa-trash-alt"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <a href="<?php echo e(route('shop.checkout.onepage.index')); ?>" class="themeBtn action-btn proc-to-pay text-center">proceed to pay</a>
                        </div>
                    </div>
                <form id="add-to-cart" action="<?php echo e(route('cart.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id">
                    <input type="hidden" name="quantity" value="1">
                </form>
                <form id="remove-to-cart" action="<?php echo e(route('shop.checkout.cart.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="rmvQty" value="1">
                    <input type="hidden" name="item_id">
                    <input type="hidden" name="quantity" value="1">
                </form>
            <?php else: ?>
                <div class="row cartItemCard">
                    <div class="col-sm-12 text-center font-weight-bold">
                        Your Cart is empty.
                    </div>
                    <br>
                </div>
                <a href="<?php echo e(route('shop.home.index')); ?>" class="themeBtn text-center">Go Back To Shop</a>
            <?php endif; ?>
        </div>
    </div>
    <!-- END: Step 2 -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/velocity/views/checkout/cart/index.blade.php ENDPATH**/ ?>