<?php $__env->startSection('content'); ?>

    <?php if($innerBannerContent = $content->where('slug', 'contactUsInnerBanner')->first()): ?>
        <div class="innerBanner">
            <img src="<?php echo e(asset($innerBannerContent->content['img']['value'])); ?>" class="w-100" alt="">
            <div class="overlay">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <h2><?php echo e($innerBannerContent->content['h2']['value']); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if($contactUsInnerContent = $content->where('slug', 'contactUsInner')->first()): ?>
        <section class="contactInner">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="contactHead">
                            <h2><?php echo e($contactUsInnerContent->content['contactHead']['h2']['value']); ?></h2>
                            <ul>
                                <li><?php echo e($contactUsInnerContent->content['contactHead']['ul'][0]['value']); ?></li>
                                <li><?php echo e($contactUsInnerContent->content['contactHead']['ul'][1]['value']); ?></li>
                            </ul>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="addressContent">
                                    <h3><?php echo e($contactUsInnerContent->content['addressContent-1']['h3-1']['value']); ?></h3>
                                    <p><?php echo $contactUsInnerContent->content['addressContent-1']['p']['value']; ?></p>
                                    <h3 class="pt-4 mb-4"><?php echo e($contactUsInnerContent->content['addressContent-1']['h3-2']['value']); ?></h3>
                                    <a href=""><?php echo e($contactUsInnerContent->content['addressContent-1']['a']['value']); ?></a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="addressContent">
                                    <h3><?php echo e($contactUsInnerContent->content['addressContent-2']['h3']['value']); ?></h3>
                                    <p><?php echo $contactUsInnerContent->content['addressContent-2']['p-1']['value']; ?></p>
                                    <p class="mt-5"><?php echo $contactUsInnerContent->content['addressContent-2']['p-2']['value']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contactback">
                            <form class="contactForm">
                                <div class="form-group">
                                    <label>Your Name (required)</label>
                                    <input type="text" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Your Email (required)</label>
                                    <input type="text" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Your Message</label>
                                    <textarea type="text" class="form-control"></textarea>
                                </div>
                                <button class="contactBtn">SEND</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/contact.blade.php ENDPATH**/ ?>