<?php $__env->startSection('content'); ?>

    <!-- Begin: Main Slider -->
    <section class="main-slider p-0" id="mainSlider">
        <div class="swiper-container homeSlider">
            <div class="swiper-wrapper">
                <?php if($sliderContent = $content->where('slug', 'mainSlider')->first()): ?>
                    <?php $__currentLoopData = $sliderContent->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="articleColumn">
                                <ul>
                                    <?php $__currentLoopData = $slider['ul']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="flip-card" tabIndex="0">
                                                <div class="flip-card-inner">
                                                    <div class="flip-card-front">
                                                    </div>
                                                    <div class="flip-card-back"><?php echo $li['value']; ?></div>
                                                </div>
                                            </div>
                                        </li>
                                        <?php if($loop->iteration === 3): ?>
                                            <li></li>
                                            <li></li>
                                            <li></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                            <div class="slide-inner bg-image">
                                <div class="container">
                                    <div class="row align-items-center justify-content-between">
                                        <div class="col-lg-6">
                                            <h1 data-swiper-parallax="-200"><?php echo e($slider['h1']['value']); ?></h1>
                                            <h2 data-swiper-parallax="-200"><?php echo e($slider['h2']['value']); ?></h2>
                                            <p data-swiper-parallax="-200"><?php echo e($slider['p']['value']); ?></p>
                                        </div>
                                        <div class="col-lg-6">
                                            <figure data-magnetic>
                                                <img src="<?php echo e(asset($slider['figure']['value'])); ?>"
                                                     class="img-fluid"
                                                     alt="">
                                            </figure>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="swiper-next"><i class="fal fa-chevron-right"></i></div>
            <div class="swiper-prev"><i class="fal fa-chevron-left"></i></div>
        </div>
    </section>
    <!-- End: Main Slider -->

    <!-- About Sec Start -->
    <?php if($aboutContent = $content->where('slug', 'aboutSec')->first()): ?>
        <section class="aboutSec">
            <div class="aboutTop">
                <img src="<?php echo e(asset($aboutContent->content['aboutTop'][0]['value'])); ?>" class="img-fluid img5" alt="">
                <img src="<?php echo e(asset($aboutContent->content['aboutTop'][1]['value'])); ?>" class="img-fluid img6" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-between">
                    <div class="offset-md-1 col-md-4">
                        <div class="abtOne">
                            <figure>
                                <img src="<?php echo e(asset($aboutContent->content['abtOne']['figure']['value'])); ?>"
                                     class="img-fluid"
                                     alt="">
                            </figure>
                            <h2><?php echo e($aboutContent->content['abtOne']['h2']['value']); ?></h2>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="Line"></div>
                        <div class="aboutTwo">
                            <h3><?php echo $aboutContent->content['aboutTwo']['h3']['value']; ?></h3>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5><?php echo e($aboutContent->content['aboutTwo']['h5']['value']); ?></h5>
                        <?php echo $aboutContent->content['aboutTwo']['p']['value']; ?>

                    </div>
                    <div class="col-md-6">
                        <div class="aboutThree">
                            <figure>
                                <img src="<?php echo e(asset($aboutContent->content['aboutThree'][0]['value'])); ?>" class="img-fluid"
                                     alt="">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <img src="<?php echo e(asset($aboutContent->content['aboutThree'][1]['value'])); ?>" class="img-fluid img7" alt="">
            <img src="<?php echo e(asset($aboutContent->content['aboutThree'][2]['value'])); ?>" class="img-fluid img8" alt="">
        </section>
    <?php endif; ?>
    <!-- About Sec End -->

    <!-- Story Sec Start -->
    <?php if($storyContent = $content->where('slug', 'storySec')->first()): ?>
        <section class="storySec">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8 text-center">
                        <div class="storyContent">
                            <h2 class="secHeading"><?php echo $storyContent->content['secHeading']['value']; ?></h2>
                            <?php echo $storyContent->content['secPara']['value']; ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!-- Story Sec End -->

    <!-- Delight Sec Start -->
    <?php if($delightContent = $content->where('slug', 'delightSec')->first()): ?>
        <section class="aboutSec delightSec">
            <div class="aboutTop">
                <img src="<?php echo e(asset($delightContent->content['aboutTop'][0]['value'])); ?>" class="img-fluid img8" alt="">
                <img src="<?php echo e(asset($delightContent->content['aboutTop'][1]['value'])); ?>" class="delgithRight" alt="">
            </div>
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-5">
                        <div class="abtOne">
                            <figure>
                                <img src="<?php echo e(asset($delightContent->content['abtOne']['value'])); ?>" class="img-fluid"
                                     alt="">
                            </figure>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="Line"></div>
                        <div class="aboutTwo">
                            <h3><?php echo e($delightContent->content['aboutTwo']['value']); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <p><?php echo $delightContent->content['col-md-4-1']['value']; ?></p>
                        <h6><?php echo e($delightContent->content['h6']['value']); ?></h6>
                        <figure class="delightLogo">
                            <img src="<?php echo e(asset($delightContent->content['figure-1']['value'])); ?>" class="img-fluid"
                                 alt="">
                        </figure>
                    </div>
                    <div class="col-md-4">
                        <h4><?php echo e($delightContent->content['col-md-4-2']['value']); ?></h4>
                        <figure>
                            <img src="<?php echo e(asset($delightContent->content['figure-2']['value'])); ?>" class="img-fluid"
                                 alt="">
                        </figure>
                    </div>
                    <div class="col-md-4">
                        <div class="centerImg">
                            <figure>
                                <img src="<?php echo e(asset($delightContent->content['figure-3']['value'])); ?>"
                                     class="img-fluid img11"
                                     alt="">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <img src="<?php echo e(asset($delightContent->content['figure-4']['value'])); ?>" class="img-fluid img6" alt="">
            <img src="<?php echo e(asset($delightContent->content['figure-5']['value'])); ?>" class="img-fluid delgithLft" alt="">
        </section>
    <?php endif; ?>
    <!-- Delight Sec End -->

    <!-- Menu Sec Start -->
    <?php if($menuSecContent = $content->where('slug', 'menuSec')->first()): ?>
        <section class="menuSec">
            <img src="<?php echo e(asset($menuSecContent->content['img'][0]['value'])); ?>" class="img-fluid img12" alt="">
            <img src="<?php echo e(asset($menuSecContent->content['img'][1]['value'])); ?>" class="img-fluid img13" alt="">
            <div class="container">
                <h2 class="secHeading text-center mb-5"><?php echo $menuSecContent->content['secHeading']['value']; ?></h2>
                <?php if(count($categories)): ?>
                    <div class="row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="cofeHeading">
                                    <h2><?php echo e($category->name); ?></h2>
                                </div>


                                <?php $__empty_1 = true; $__currentLoopData = app('Webkul\Product\Repositories\ProductRepository')->getAllByCategoryId($category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFlat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="cofeList">
                                        <a href="<?php echo e(route('shop.home.show', $productFlat->url_key)); ?>" class="codeBox">
                                            <figure><img
                                                    src="<?php echo e(productimage()->getProductBaseImage($productFlat)['small_image_url']); ?>"
                                                    class="img-fluid"
                                                    alt="img"></figure>
                                            <div class="cofeContent">
                                                <ul>
                                                    <li>
                                                        <h2><?php echo e($productFlat->name); ?></h2>
                                                        <div class="dot"></div>
                                                        <span>
                                                        <?php if(isset($productFlat->special_price)): ?>
                                                                <del>$<?php echo e(round($productFlat->price)); ?></del>
                                                                <strong>$<?php echo e(round($productFlat->special_price)); ?></strong>
                                                            <?php else: ?>
                                                                <strong>$<?php echo e(round($productFlat->price)); ?></strong>
                                                            <?php endif; ?>
                                                    </span>
                                                    </li>
                                                </ul>
                                                <p><?php echo e($productFlat->description); ?></p>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="cofeList">
                                        <div class="codeBox">
                                            <p>No product found.</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
    <!-- Menu Sec End -->

    <!-- Shop Sec Start -->
    <?php if(count($newProducts)): ?>
        <?php if($shopSecContent = $content->where('slug', 'shopSec')->first()): ?>
            <section class="shopSec">
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-8 text-center">
                            <div class="storyContent">
                                <h2 class="secHeading"><?php echo $shopSecContent->content['secHeading']['value']; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        <!-- Shop Sec End -->

        <!-- Product Sec Start -->
        <section class="productSec">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="productBox">
                                <figure>
                                    <img src="<?php echo e(productimage()->getProductBaseImage($productFlat)['large_image_url']); ?>"
                                         class="img-fluid"
                                         alt="">
                                </figure>
                                <div class="productContent">
                                    <h4>
                                        <?php echo e($newProduct->name); ?>

                                        <?php if(isset($newProduct->special_price)): ?>
                                            <span>$<?php echo e(round($newProduct->special_price)); ?></span>
                                        <?php else: ?>
                                            <span>$<?php echo e(round($newProduct->price)); ?></span>
                                        <?php endif; ?>
                                    </h4>
                                    <a href="<?php echo e(route('shop.home.show', $newProduct->url_key)); ?>" class="productBtn">ADD
                                        TO CART</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!-- Product Sec End -->
    <?php endif; ?>

    <!-- Gallery Sec Start -->
    <?php if($galleryContent = $content->where('slug', 'gallerySec')->first()): ?>
        <section class="menuSec gallerySec">
            <img src="<?php echo e(asset($galleryContent->content['figure-1']['value'])); ?>" class="img-fluid left" alt="">
            <img src="<?php echo e(asset($galleryContent->content['figure-2']['value'])); ?>" class="img-fluid right" alt="">
            <div class="container-fluid p-0">
                <h2 class="secHeading text-center mb-5"><?php echo $galleryContent->content['secHeading']['value']; ?></h2>
                <div class="row">
                    <div class="col-md-12">
                        <div class="gallerySlider">
                            <a href="" class="galleryImg" data-fancybox="">
                                <img src="<?php echo e(asset($galleryContent->content['gallerySlider']['galleryImg-1']['value'])); ?>"
                                     class="img-fluid w-100"
                                     alt="">
                            </a>
                            <a href="" class="galleryImg" data-fancybox="">
                                <img src="<?php echo e(asset($galleryContent->content['gallerySlider']['galleryImg-2']['value'])); ?>"
                                     class="img-fluid w-100"
                                     alt="">
                            </a>
                            <a href="" class="galleryImg" data-fancybox="">
                                <img src="<?php echo e(asset($galleryContent->content['gallerySlider']['galleryImg-3']['value'])); ?>"
                                     class="img-fluid w-100"
                                     alt="">
                            </a>
                            <a href="" class="galleryImg" data-fancybox="">
                                <img src="<?php echo e(asset($galleryContent->content['gallerySlider']['galleryImg-4']['value'])); ?>"
                                     class="img-fluid w-100"
                                     alt="">
                            </a>
                            <a href="" class="galleryImg" data-fancybox="">
                                <img src="<?php echo e(asset($galleryContent->content['gallerySlider']['galleryImg-5']['value'])); ?>"
                                     class="img-fluid w-100"
                                     alt="">
                            </a>
                            <a href="" class="galleryImg" data-fancybox="">
                                <img src="<?php echo e(asset($galleryContent->content['gallerySlider']['galleryImg-6']['value'])); ?>"
                                     class="img-fluid w-100"
                                     alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!-- Gallery Sec End -->

    <!-- History Sec Start -->
    <?php if($historyContent = $content->where('slug', 'historySec')->first()): ?>
        <section class="historySec">
            <img src="<?php echo e(asset($historyContent->content['figure-1']['value'])); ?>" class="img-fluid historyLogo" alt="">
            <div class="container-fluid p-0">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="historyContent">
                            <h2><?php echo e($historyContent->content['historyContent']['h2']['value']); ?></h2>
                            <?php echo $historyContent->content['historyContent']['para']['value']; ?>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <figure>
                            <img src="<?php echo e(asset($historyContent->content['historyContent']['figure-2']['value'])); ?>"
                                 class="img-fluid"
                                 alt="">
                        </figure>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!-- History Sec End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/home/index2.blade.php ENDPATH**/ ?>