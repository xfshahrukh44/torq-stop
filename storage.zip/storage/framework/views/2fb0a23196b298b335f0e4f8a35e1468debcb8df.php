<?php $__env->startSection('page_title'); ?>
    <?php echo e(__('shop::app.checkout.onepage.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .no-arrow {
            -moz-appearance: textfield;
        }

        .no-arrow::-webkit-inner-spin-button {
            display: none;
        }

        .no-arrow::-webkit-outer-spin-button,
        .no-arrow::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
    </style>
    <div class="innerBanner">
        <img src="<?php echo e(asset('themes\default\assets\images\innerBan.jpg')); ?>" class="w-100" alt="">
        <div class="overlay">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <h2>Billing information
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Begin: Step 1 -->
    <div class="checkOutStyle">
        <div class="container-md">
            <div class="row">
                <form action="<?php echo e(route('shop.checkout.proceed-to-checkout')); ?>" method="POST" class="row formStyle">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-12">
                        <div class="title inner">
                            <!-- <h2 class="section-heading">Billing Address</h2> -->
                            <h4>Fill the form below to complete your purchase</h4>
                            
                            
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label>First Name</label>
                        <input id="first_name" type="text"
                               class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="first_name">
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback mb-2" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label>Last Name</label>
                        <input id="last_name" type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="last_name">
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label>Email address</label>
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback mb-2" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label>Phone</label>
                        <input name="phone" id="phone" name="phone"
                               class="form-control no-arrow <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label>Password</label>
                        <input id="password" type="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback mb-2" role="alert">

                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label>Confirm password</label>
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                               autocomplete="new-password">
                    </div>
                    <div class="col-md-12">
                        <label>Address</label>
                        <textarea rows="4" class="form-control" name="address"></textarea>
                    </div>
                    <div class="col-md-6">
                        <label>Country</label>
                        <input type="text" class="form-control" name="country">
                    </div>
                    <div class="col-md-6">
                        <label>State/Province</label>
                        <input type="text" class="form-control" name="state">
                    </div>
                    <div class="col-md-6">
                        <label>City</label>
                        <input type="text" class="form-control" name="city">
                    </div>
                    <div class="col-md-6">
                        <label>Zip/Postal Code</label>
                        <input type="text" class="form-control" name="zip_code">
                    </div>
                    <div class="col-md-12">
                        <div class="checkbox">
                            <input type="checkbox" id="box-1" name="create_account" checked>
                            <label for="box-1">Create an account for later use</label>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="checkbox">
                            <input type="checkbox" id="box-2" name="ship_to_address" checked>
                            <label for="box-2">Ship to the same address mentioned above</label>
                        </div>
                    </div>
                    <div class="col-md-12 title my-5 text-center">
                        <h2 class="section-heading">Order Summary</h2>
                    </div>
                    <div class="col-md-12 order-summery">
                        <div class="row no-gutters">
                            <div class="col-6">
                                <span>Subtotal (<?php echo e($cart->items_qty ?? ''); ?> items)</span>
                            </div>
                            <div class="col-6 text-right">
                                <strong>$<?php echo e($cart->sub_total ?? ''); ?></strong>
                            </div>
                            <hr class="w-100">
                            <div class="col-6">
                                <span>Shipping fee</span>
                            </div>

                            <?php if(!empty($shippingMethods)): ?>
                                <div class="col-6 text-right">
                                    <strong><?php echo e($shippingMethods['price'] !== 0 ? 'USD '.$shippingMethods['price'] : $shippingMethods['price']); ?></strong>
                                    <input type="hidden" name="shipping_method"
                                           value="<?php echo e($shippingMethods['method']); ?>">
                                    <input type="hidden" name="payment_method" value="<?php echo e($shippingMethods['method']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[method]"
                                           value="<?php echo e($shippingMethods['method']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[method_title]"
                                           value="<?php echo e($shippingMethods['method_title']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[carrier_title]"
                                           value="<?php echo e($shippingMethods['carrier_title']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[method_description]"
                                           value="<?php echo e($shippingMethods['method_description']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[price]"
                                           value="<?php echo e($shippingMethods['price']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[base_price]"
                                           value="<?php echo e($shippingMethods['base_price']); ?>">
                                    <input type="hidden" name="selected_shipping_rate[discount_amount]"
                                           value="<?php echo e(round($shippingMethods['discount_amount'])); ?>">
                                    <input type="hidden" name="selected_shipping_rate[base_discount_amount]"
                                           value="<?php echo e(round($shippingMethods['base_discount_amount'])); ?>">

                                </div>

                                <hr class="w-100">
                                
                                
                                
                                
                                
                                
                                
                                <div class="col-6">
                                    <span>Total</span>
                                </div>
                                <div class="col-6 text-right">
                                    <strong>$<?php echo e($cart->grand_total ?? ''); ?></strong>
                                </div>
                                <hr class="w-100">
                                <div class="col-md-12 mt-4">
                                    <button type="submit" class="themeBtn btnStyle btn-block proc-to-pay">Checkout with Stripe
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>

</script>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/velocity/views/checkout/onepage.blade.php ENDPATH**/ ?>