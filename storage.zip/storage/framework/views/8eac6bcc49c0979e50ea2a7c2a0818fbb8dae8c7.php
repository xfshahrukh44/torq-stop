<?php $__env->startSection('content'); ?>
    <?php $toolbarHelper = app('Webkul\Product\Helpers\Toolbar'); ?>

    <?php
        $showCompare = core()->getConfigData('general.content.shop.compare_option') == "1" ? true : false;

        $showWishlist = core()->getConfigData('general.content.shop.wishlist_option') == "1" ? true : false;
    ?>

    
    
    
    
    
    
    

    
    
    

    
    
    
    
    
    
    <div class="innerBanner">
        <img src="<?php echo e(asset(productimage()->getProductBaseImage($product)['small_image_url'])); ?>" class="w-100" alt="">
        <div class="overlay">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <h2>product Details
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="main-prodtl">
        <div class="container-md">
            <div class="row">
                <div class="col-lg-6">
                    <div class="prodtl-img">
                        <img src="<?php echo e(asset(productimage()->getProductBaseImage($product)['small_image_url'])); ?>"
                             class="w-100" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="prodtl-txt">
                        <h2 class="section-heading"><?php echo e($product->name); ?></h2>
                        <h6>
                                <span>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </span>
                            3539 Reviews
                        </h6>
                        <ul class="list-unstyled stckst">
                            <li>Price $<?php echo e($product->special_price ?? $product->price); ?></li>
                            <li>
                                <?php if($product->isSaleable()): ?>
                                    <i class="fa fa-check" aria-hidden="true"></i>In stock
                                <?php else: ?>
                                    <i class="fa fa-cross" aria-hidden="true"></i>Out of stock
                                <?php endif; ?>
                            </li>
                        </ul>

                        <form action="<?php echo e(route('cart.add', $product->product_id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>">
                            <div class="ad-crtst ad-crtstwo">
                                <ul class="list-unstyled">
                                    <li>
                                        <div class="number">
                                            <span class="minus">-</span>
                                            <input type="text" name="quantity" value="1">
                                            <span class="plus">+</span>
                                        </div>
                                    </li>
                                    <li>
                                        <button type="submit"
                                                class="themeBtn" <?php echo e($product->isSaleable() ? '' : 'disabled'); ?>>
                                            <?php echo e(($product->type == 'booking') ?  __('shop::app.products.book-now') :  __('shop::app.products.add-to-cart')); ?>

                                        </button>
                                    </li>
                                </ul>
                                <h5><?php echo e($product->short_description); ?></h5>
                                <p><?php echo e($product->description); ?></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="ratd-txt">
                        <h2>Product Discription</h2>
                        <p><?php echo e($product->description); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shop::layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/home/show.blade.php ENDPATH**/ ?>