<!DOCTYPE html>
<html lang="en">

<head>

    <title>Brand New Day</title>

    <!-- Required meta tags -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/fontawesome.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/jquery.fancybox.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/slick.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/slick-theme.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/swiper-bundle.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/aos.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/custom.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/slider.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('themes/default/assets/css/responsive.css')); ?>"/>

</head>
<body>
<?php echo $__env->make('shop::layouts.header.index2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('shop::layouts.footer.footer2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('themes/default/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/magnetic.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/gsap.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/scrollTrigger.js')); ?>"></script>
<script src="<?php echo e(asset('themes/default/assets/js/custom.min.js')); ?>"></script>

</body>
</html><?php /**PATH /home/v23demowebsite/public_html/brandnew-ecomm/resources/themes/default/views/layouts/master2.blade.php ENDPATH**/ ?>